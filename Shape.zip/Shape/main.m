//
//  main.m
//  Shape
//
//  Created by SEI-HYONG PARK on 6/26/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, @"ShapeAppDelegate");
    [pool release];
    return retVal;
}
