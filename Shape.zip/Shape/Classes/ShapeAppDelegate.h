//
//  ShapeAppDelegate.h
//  Shape
//
//  Created by SEI-HYONG PARK on 6/26/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
@class View;

@interface ShapeAppDelegate : NSObject <UIApplicationDelegate> {
    View *view;
	UIWindow *window;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end

