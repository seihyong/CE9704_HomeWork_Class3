//
//  View.m
//  Shape
//
//  Created by SEI-HYONG PARK on 6/26/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "View.h"

@implementation View


- (id)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor whiteColor];
    }
    return self;
}

- (void) drawRect: (CGRect) rect {
	// Drawing code
	CGRect b = self.bounds;
	CGFloat radius = .3 * b.size.width;	//in pixels
	
	//Print View's fram and bounds properties to the Console window
	NSLog(@"View's origin == (%g, %g), View's size == %g × %g",
		  b.origin.x,
		  b.origin.y,
		  b.size.width,
		  b.size.height);
	
	CGContextRef c = UIGraphicsGetCurrentContext();
	CGContextBeginPath(c); //unnecessary here: the path is already empty.
	CGContextTranslateCTM(c, b.size.width / 2, b.size.height / 2);

	CGContextSetShadow(c, CGSizeMake(10, -10), 20);

	//The circle
	CGRect r = CGRectMake(-radius, -radius, 2 * radius, 2 * radius);
	CGContextAddEllipseInRect(c, r);
	CGContextSetLineWidth(c, 50.0);
	CGContextSetRGBStrokeColor(c, 1.0, 0.0, 0.0, 1);
	CGContextStrokePath(c);

	/*
	//The rectangle
	CGRect s = CGRectMake(-1.6*radius, -0.25*radius, 3.2*radius, 0.5*radius);
	CGContextAddRect(c,s);
	CGContextSetRGBFillColor(c, 0.0, 0.0, 1.0, 1);
	CGContextFillPath(c);	
	*/
	
	//The rectangle using CGContextScaleCTM
	CGContextScaleCTM(c, 1.6, 0.25);
	CGContextAddRect(c,r);
	CGContextSetRGBFillColor(c, 0.0, 0.0, 1.0, 0.9);
	CGContextFillPath(c);	
	CGContextScaleCTM(c, 1/1.6, 1/0.25);
	
	//The writing
	CGContextSetRGBFillColor(c, 1.0, 1.0, 1.0, 0.9);
	UIFont *f = [UIFont systemFontOfSize: 35.0];
	//English or Korean:
	NSString *t = NSLocalizedString(@"Subway", @"displayed with drawAtPoint:");		
	CGSize size = [t sizeWithFont: f]; //get the size of text
	CGFloat x = -size.width/2;
	CGFloat y = -size.height/2;
	CGPoint p = CGPointMake(x,y);	//centering the text
	[t drawAtPoint: p withFont: f];
	
}

- (void)dealloc {
    [super dealloc];
}


@end
