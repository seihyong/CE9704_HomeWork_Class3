//
//  View.h
//  Shape
//
//  Created by SEI-HYONG PARK on 6/26/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface View : UIView {

}

@end
